package com.example.download_any_file

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
